
'use client';
import { useState } from 'react';

export default function GuestPage() {
  const [step, setStep] = useState(1);

  return (
    <div style={{padding:20,fontFamily:'sans-serif'}}>
      <h2>RSVP (крок {step}/5)</h2>

      {step === 1 && (
        <div>
          <p>Чи будете на весіллі?</p>
          <button onClick={()=>setStep(2)}>Так</button>
          <button onClick={()=>alert('Дякуємо!')}>Ні</button>
        </div>
      )}

      {step === 2 && (
        <div>
          <p>Чи будете на розписці?</p>
          <button onClick={()=>setStep(3)}>Так</button>
          <button onClick={()=>setStep(3)}>Ні</button>
        </div>
      )}

      {step === 3 && (
        <div>
          <p>Діти?</p>
          <button onClick={()=>setStep(4)}>Так</button>
          <button onClick={()=>setStep(4)}>Ні</button>
        </div>
      )}

      {step === 4 && (
        <div>
          <p>+1?</p>
          <button onClick={()=>setStep(5)}>Так</button>
          <button onClick={()=>setStep(5)}>Ні</button>
        </div>
      )}

      {step === 5 && (
        <div>
          <p>Коментар</p>
          <textarea />
          <button onClick={()=>alert('Дякуємо за відповідь 🎉')}>Відправити</button>
        </div>
      )}
    </div>
  );
}
