
export default function Admin() {
  return (
    <div style={{padding:20,fontFamily:'sans-serif'}}>
      <h1>Admin Dashboard</h1>
      <p>Статистика RSVP (заглушка)</p>

      <ul>
        <li>Всього гостей: 25</li>
        <li>Відповіли: 18</li>
        <li>Будуть: 14</li>
        <li>Не будуть: 4</li>
      </ul>
    </div>
  );
}
