
export async function POST(req) {
  const body = await req.json();

  // Telegram webhook stub
  console.log('Telegram event:', body);

  return Response.json({ ok: true });
}
