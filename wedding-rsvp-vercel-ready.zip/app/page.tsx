
export default function Home() {
  return (
    <div style={{display:'flex',height:'100vh',alignItems:'center',justifyContent:'center',fontFamily:'sans-serif'}}>
      <div>
        <h1>Wedding RSVP</h1>
        <p>Відкрий персональне запрошення</p>
      </div>
    </div>
  );
}
