# Wedding RSVP SaaS (Vercel-ready)

## Setup
1. npm install
2. npm run dev

## Features
- Персональні RSVP лінки
- 5 кроків опитування
- Адмін панель
- Telegram інтеграція (API route)
- Український інтерфейс

## Deploy
- Push to GitHub
- Import to Vercel
